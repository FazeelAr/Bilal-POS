default_app_config = 'sales.apps.SalesConfig'
