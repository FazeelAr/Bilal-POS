from django.utils import timezone
from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models import Sum, Count
from django.db.models.functions import TruncDate, TruncMonth
from datetime import datetime, date
from django.db import transaction
from django.shortcuts import get_object_or_404

from .models import Client, Order, OrderItem, Receipt, ReceiptItem
from .serializers import (
    ClientSerializer,
    OrderSerializer,
    OrderCreateSerializer,
    ReceiptSerializer,
    ReceiptCreateSerializer,
    ReceiptReprintSerializer
)


class ReceiptViewSet(viewsets.ModelViewSet):
    """ViewSet for Receipt model"""
    queryset = Receipt.objects.all().select_related('order', 'customer').prefetch_related('items')
    serializer_class = ReceiptSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        """Filter receipts based on query parameters"""
        queryset = super().get_queryset()
        
        # Filter by customer
        customer_id = self.request.query_params.get('customer_id')
        if customer_id:
            queryset = queryset.filter(customer_id=customer_id)
        
        # Filter by order
        order_id = self.request.query_params.get('order')
        if order_id:
            queryset = queryset.filter(order_id=order_id)
        
        # Filter by date range
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date and end_date:
            queryset = queryset.filter(receipt_date__range=[start_date, end_date])
        
        # Filter by receipt number
        receipt_number = self.request.query_params.get('receipt_number')
        if receipt_number:
            queryset = queryset.filter(receipt_number__icontains=receipt_number)
        
        return queryset
    
    @action(detail=True, methods=['post'], url_path='reprint')
    def reprint(self, request, pk=None):
        """Increment reprint count for a receipt"""
        try:
            receipt = self.get_object()
            receipt.reprint_count += 1
            receipt.last_reprinted_at = timezone.now()
            receipt.save()
            
            return Response({
                'message': 'Receipt reprinted successfully',
                'reprint_count': receipt.reprint_count,
                'last_reprinted_at': receipt.last_reprinted_at
            }, status=status.HTTP_200_OK)
            
        except Exception as e:
            print(f"Error in reprint: {e}")
            import traceback
            traceback.print_exc()
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    @action(detail=False, methods=['get'], url_path='by-order/(?P<order_id>\d+)')
    def by_order(self, request, order_id=None):
        """Get receipt for a specific order"""
        try:
            # Try to get receipt by order ID
            receipt = Receipt.objects.get(order_id=order_id)
            serializer = self.get_serializer(receipt)
            return Response(serializer.data)
        except Receipt.DoesNotExist:
            return Response(
                {'error': 'Receipt not found for this order'}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            print(f"Error in by_order: {e}")
            import traceback
            traceback.print_exc()
            return Response(
                {'error': str(e)}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    @action(detail=False, methods=['get'], url_path='by-customer/(?P<customer_id>\d+)')
    def by_customer(self, request, customer_id=None):
        """Get all receipts for a specific customer"""
        try:
            customer = Client.objects.get(id=customer_id)
        except Client.DoesNotExist:
            return Response(
                {'error': 'Customer not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        receipts = self.get_queryset().filter(customer=customer)
        page = self.paginate_queryset(receipts)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = self.get_serializer(receipts, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['post'], url_path='create-from-order')
    def create_from_order(self, request):
        """Create a receipt from order data"""
        serializer = ReceiptCreateSerializer(data=request.data)
        if serializer.is_valid():
            try:
                receipt = serializer.save()
                return Response(ReceiptSerializer(receipt).data, status=status.HTTP_201_CREATED)
            except Exception as e:
                print(f"Error creating receipt: {e}")
                return Response(
                    {'error': str(e)}, 
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            

class ClientViewSet(viewsets.ModelViewSet):
    """ViewSet for Client (Customer) operations"""
    queryset = Client.objects.all().order_by('name')
    serializer_class = ClientSerializer
    permission_classes = [IsAuthenticated]
    
    @action(detail=False, methods=['get'], url_path='balances')
    def customer_balances(self, request):
        """
        Get all customers with their balances
        Query params:
        - sort: 'balance' or 'name' (default: 'name')
        - order: 'asc' or 'desc' (default: 'asc')
        """
        try:
            # Get all customers
            customers = Client.objects.all()
            
            # Apply sorting
            sort_by = request.query_params.get('sort', 'name')
            order = request.query_params.get('order', 'asc')
            
            if sort_by == 'balance':
                if order == 'desc':
                    customers = customers.order_by('-balance')
                else:
                    customers = customers.order_by('balance')
            else:  # sort by name
                if order == 'desc':
                    customers = customers.order_by('-name')
                else:
                    customers = customers.order_by('name')
            
            # Calculate total balance
            total_balance = customers.aggregate(total=Sum('balance'))['total'] or 0
            
            # Get customer data
            customer_data = []
            for customer in customers:
                customer_data.append({
                    'id': customer.id,
                    'name': customer.name,
                    'balance': float(customer.balance),
                    'order_count': customer.orders.count(),
                    'last_order_date': customer.orders.order_by('-date').first().date if customer.orders.exists() else None
                })
            
            return Response({
                'customers': customer_data,
                'total_balance': float(total_balance),
                'count': len(customer_data),
                'positive_balance_count': len([c for c in customer_data if c['balance'] > 0]),
                'negative_balance_count': len([c for c in customer_data if c['balance'] < 0]),
                'zero_balance_count': len([c for c in customer_data if c['balance'] == 0])
            })
            
        except Exception as e:
            print(f"Error in customer_balances: {e}")
            import traceback
            traceback.print_exc()
            return Response(
                {'error': f'Internal server error: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class OrderViewSet(viewsets.ModelViewSet):
    """ViewSet for Order operations"""
    queryset = Order.objects.all().select_related('client').prefetch_related('items')
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        """Filter orders based on query parameters"""
        queryset = super().get_queryset()
        
        # Filter by customer
        customer_id = self.request.query_params.get('customer')
        if customer_id:
            queryset = queryset.filter(client_id=customer_id)
        
        # Filter by date range
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date and end_date:
            queryset = queryset.filter(date__range=[start_date, end_date])
        
        # Filter by payment status
        payment_status = self.request.query_params.get('payment_status')
        if payment_status:
            queryset = queryset.filter(payment_status=payment_status)
        
        return queryset
    
    @action(detail=False, methods=['post'], url_path='create')
    def create_order(self, request):
        """Create a new order with items"""
        serializer = OrderCreateSerializer(data=request.data)
        if serializer.is_valid():
            try:
                order = serializer.save()
                return Response(
                    OrderSerializer(order).data,
                    status=status.HTTP_201_CREATED
                )
            except Exception as e:
                print(f"Error creating order: {e}")
                return Response(
                    {'error': str(e)},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=False, methods=['get'], url_path='reports/daily')
    def daily_report(self, request):
        """
        Generate daily sales report
        Query params:
        - date: YYYY-MM-DD (default: today)
        - customer: customer ID (optional)
        """
        # Get date parameter or use today
        date_str = request.query_params.get('date')
        if date_str:
            try:
                report_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            except ValueError:
                return Response(
                    {'error': 'Invalid date format. Use YYYY-MM-DD'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        else:
            report_date = date.today()
        
        # Filter orders
        orders = Order.objects.filter(date=report_date).select_related('client').prefetch_related('items__item')
        
        # Filter by customer if provided
        customer_id = request.query_params.get('customer')
        customer_filter = None
        customer_balance = None
        
        if customer_id:
            orders = orders.filter(client_id=customer_id)
            try:
                customer = Client.objects.get(id=customer_id)
                customer_filter = customer.name
                customer_balance = float(customer.balance)
            except Client.DoesNotExist:
                customer_filter = f"Customer ID: {customer_id}"
        
        # Calculate totals
        total_sales = orders.aggregate(total=Sum('total'))['total'] or 0
        total_paid = orders.aggregate(total=Sum('payment_amount'))['total'] or 0
        total_due = orders.aggregate(total=Sum('balance_due'))['total'] or 0
        
        # Get order details
        order_details = []
        for order in orders:
            order_data = {
                'id': order.id,
                'customer_name': order.client.name,
                'order_date': order.date.strftime('%Y-%m-%d'),
                'amount': float(order.total),
                'payment_amount': float(order.payment_amount),
                'payment_status': order.payment_status,
                'balance_due': float(order.balance_due),
                'items_count': order.items.count(),
                'items': []
            }
            
            # Add order items
            for item in order.items.all():
                order_data['items'].append({
                    'name': item.item.name,
                    'quantity': float(item.quantity),
                    'price': float(item.price),
                    'total': float(item.quantity * item.price)
                })
            
            order_details.append(order_data)
        
        return Response({
            'date': report_date.strftime('%Y-%m-%d'),
            'total_sales': float(total_sales),
            'total_paid': float(total_paid),
            'total_due': float(total_due),
            'order_count': orders.count(),
            'customer_filter': customer_filter,
            'customer_balance': customer_balance,
            'orders': order_details
        })
    
    @action(detail=False, methods=['get'], url_path='reports/monthly')
    def monthly_report(self, request):
        """
        Generate monthly sales report
        Query params:
        - start_date: YYYY-MM-DD (optional)
        - end_date: YYYY-MM-DD (optional)
        - customer: customer ID (optional)
        """
        try:
            orders = Order.objects.all()
            
            # Filter by customer if provided
            customer_id = request.query_params.get('customer')
            customer_filter = None
            customer_balance = None
            
            if customer_id:
                orders = orders.filter(client_id=customer_id)
                try:
                    customer = Client.objects.get(id=customer_id)
                    customer_filter = customer.name
                    customer_balance = float(customer.balance)
                except Client.DoesNotExist:
                    customer_filter = f"Customer ID: {customer_id}"
            
            # Filter by date range if provided
            start_date = request.query_params.get('start_date')
            end_date = request.query_params.get('end_date')
            
            if start_date:
                try:
                    start = datetime.strptime(start_date, '%Y-%m-%d').date()
                    orders = orders.filter(date__gte=start)
                except ValueError:
                    return Response(
                        {'error': 'Invalid start_date format. Use YYYY-MM-DD'},
                        status=status.HTTP_400_BAD_REQUEST
                    )
            
            if end_date:
                try:
                    end = datetime.strptime(end_date, '%Y-%m-%d').date()
                    orders = orders.filter(date__lte=end)
                except ValueError:
                    return Response(
                        {'error': 'Invalid end_date format. Use YYYY-MM-DD'},
                        status=status.HTTP_400_BAD_REQUEST
                    )
            
            # Group by month manually
            monthly_totals = {}
            monthly_orders = {}
            
            # Aggregate orders by month
            for order in orders.select_related('client').iterator():
                try:
                    month_key = order.date.strftime('%Y-%m')
                    
                    if month_key not in monthly_totals:
                        monthly_totals[month_key] = 0
                        monthly_orders[month_key] = []
                    
                    monthly_totals[month_key] += float(order.total)
                    
                    # Get order details
                    order_data = {
                        'id': order.id,
                        'customer_name': order.client.name,
                        'order_date': order.date.strftime('%Y-%m-%d'),
                        'amount': float(order.total),
                        'payment_amount': float(order.payment_amount),
                        'payment_status': order.payment_status,
                        'balance_due': float(order.balance_due),
                        'items_count': order.items.count(),
                        'items': []
                    }
                    
                    # Get items safely
                    try:
                        for order_item in order.items.all().select_related('item'):
                            order_data['items'].append({
                                'name': order_item.item.name if order_item.item else 'Unknown',
                                'quantity': float(order_item.quantity),
                                'price': float(order_item.price),
                                'total': float(order_item.quantity * order_item.price)
                            })
                    except Exception as e:
                        print(f"Error getting items for order {order.id}: {e}")
                    
                    monthly_orders[month_key].append(order_data)
                    
                except Exception as e:
                    print(f"Error processing order {order.id}: {e}")
                    continue
            
            # Convert to list format
            result = []
            for month_key, total_sales in monthly_totals.items():
                month_orders_list = monthly_orders.get(month_key, [])
                result.append({
                    'month': month_key,
                    'total_sales': total_sales,
                    'order_count': len(month_orders_list),
                    'orders': month_orders_list
                })
            
            # Sort by month (descending)
            result.sort(key=lambda x: x['month'], reverse=True)
            
            response_data = {
                'reports': result,
                'customer_filter': customer_filter,
                'customer_balance': customer_balance
            }
            
            return Response(response_data)
            
        except Exception as e:
            print(f"Error in monthly_report: {e}")
            import traceback
            traceback.print_exc()
            return Response(
                {'error': f'Internal server error: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    @action(detail=False, methods=['get'], url_path='reports/date-range')
    def date_range_report(self, request):
        """
        Generate sales report for a date range
        Query params:
        - start_date: YYYY-MM-DD (required)
        - end_date: YYYY-MM-DD (required)
        - customer: customer ID (optional)
        """
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        
        if not start_date or not end_date:
            return Response(
                {'error': 'Both start_date and end_date are required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
        except ValueError:
            return Response(
                {'error': 'Invalid date format. Use YYYY-MM-DD'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            # Filter orders - use simple filter first
            orders = Order.objects.filter(date__gte=start, date__lte=end)
            
            # Filter by customer if provided
            customer_id = request.query_params.get('customer')
            customer_filter = None
            customer_balance = None
            
            if customer_id:
                orders = orders.filter(client_id=customer_id)
                try:
                    customer = Client.objects.get(id=customer_id)
                    customer_filter = customer.name
                    customer_balance = float(customer.balance)
                except Client.DoesNotExist:
                    customer_filter = f"Customer ID: {customer_id}"
            
            # Calculate overall totals
            totals = orders.aggregate(
                total_sales=Sum('total'),
                total_paid=Sum('payment_amount'),
                total_due=Sum('balance_due')
            )
            
            total_sales = totals['total_sales'] or 0
            total_paid = totals['total_paid'] or 0
            total_due = totals['total_due'] or 0
            
            # Get order count
            order_count = orders.count()
            
            # Get all order details for the range
            all_order_details = []
            for order in orders.select_related('client').iterator():
                try:
                    order_data = {
                        'id': order.id,
                        'customer_name': order.client.name,
                        'order_date': order.date.strftime('%Y-%m-%d'),
                        'amount': float(order.total),
                        'payment_amount': float(order.payment_amount),
                        'payment_status': order.payment_status,
                        'balance_due': float(order.balance_due),
                        'items_count': order.items.count(),
                        'items': []
                    }
                    
                    # Get items
                    try:
                        for order_item in order.items.all().select_related('item'):
                            order_data['items'].append({
                                'name': order_item.item.name if order_item.item else 'Unknown',
                                'quantity': float(order_item.quantity),
                                'price': float(order_item.price),
                                'total': float(order_item.quantity * order_item.price)
                            })
                    except Exception as e:
                        print(f"Error getting items for order {order.id}: {e}")
                    
                    all_order_details.append(order_data)
                except Exception as e:
                    print(f"Error processing order {order.id}: {e}")
                    continue
            
            # Create daily breakdown
            daily_breakdown = []
            daily_sales = {}
            daily_orders = {}
            
            # Aggregate orders by date
            for order in orders:
                date_str = order.date.strftime('%Y-%m-%d')
                if date_str not in daily_sales:
                    daily_sales[date_str] = 0
                    daily_orders[date_str] = []
                
                daily_sales[date_str] += float(order.total)
                
                # Get order details for this day
                day_order_details = []
                try:
                    order_data = {
                        'id': order.id,
                        'customer_name': order.client.name,
                        'order_date': order.date.strftime('%Y-%m-%d'),
                        'amount': float(order.total),
                        'payment_amount': float(order.payment_amount),
                        'payment_status': order.payment_status,
                        'balance_due': float(order.balance_due),
                        'items_count': order.items.count(),
                        'items': []
                    }
                    
                    for order_item in order.items.all().select_related('item'):
                        order_data['items'].append({
                            'name': order_item.item.name if order_item.item else 'Unknown',
                            'quantity': float(order_item.quantity),
                            'price': float(order_item.price),
                            'total': float(order_item.quantity * order_item.price)
                        })
                    
                    day_order_details.append(order_data)
                except Exception as e:
                    print(f"Error creating day order details: {e}")
                
                daily_orders[date_str].extend(day_order_details)
            
            # Convert to list format
            for date_str, sales in daily_sales.items():
                day_order_count = len(daily_orders[date_str]) if date_str in daily_orders else 0
                
                daily_breakdown.append({
                    'date': date_str,
                    'total_sales': sales,
                    'order_count': day_order_count,
                    'orders': daily_orders.get(date_str, [])
                })
            
            # Sort by date
            daily_breakdown.sort(key=lambda x: x['date'])
            
            result = {
                'start_date': start.strftime('%Y-%m-%d'),
                'end_date': end.strftime('%Y-%m-%d'),
                'total_sales': float(total_sales),
                'total_paid': float(total_paid),
                'total_due': float(total_due),
                'order_count': order_count,
                'orders': all_order_details,
                'daily_breakdown': daily_breakdown,
                'customer_filter': customer_filter,
                'customer_balance': customer_balance
            }
            
            return Response(result)
            
        except Exception as e:
            print(f"Error in date_range_report: {e}")
            import traceback
            traceback.print_exc()
            return Response(
                {'error': f'Internal server error: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def receipt_view(request):
    """
    Handle receipt data (can be used for logging or additional processing)
    """
    serializer = ReceiptSerializer(data=request.data)
    if serializer.is_valid():
        # Here you can add additional logic like:
        # - Logging receipt prints
        # - Sending email receipts
        # - Storing receipt copies
        # For now, just return success with the data
        return Response({
            'id': f"RCP-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'status': 'success',
            'data': serializer.validated_data
        }, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)